
import pandas as pd

# Load CSV
movies_df = pd.read_csv('sample_movies.csv')

# Save to pickle
movies_df.to_pickle('movies.pkl')

print("movies.pkl created!")
